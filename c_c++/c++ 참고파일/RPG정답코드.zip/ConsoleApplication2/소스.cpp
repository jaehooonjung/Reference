#include"GameManager.h"
void main()
{
	GameManager Gm;
	Gm.GameTitleScene();
}