#pragma once
#include"Weapon.h"
#include"MapDraw.h"
#include"Mecro.h"
class Shop
{
private:
	MapDraw m_DrawManager;
	Weapon* m_pWeaponList[256];
	int m_iWeaponCount;
public:
	void ShopMenu(Character* Player);
	void WeaponMenu(Character* Player,WEAPON Type);
	string GetTypeString(WEAPON Type);
	Shop();
	~Shop();
};

