#include "Quiz.h"



Quiz::Quiz()
{
	m_iSum = 0;
	for (int i = 1; i <= 10; i++)
		m_iSum += i;
}


Quiz::Quiz(int iNum)
{
	m_iSum = 0;
	for (int i = 1; i <= iNum; i++)
		m_iSum += i;
}

Quiz::Quiz(int iNum1, int iNum2)
{
	m_iSum = 0;
	int tmp;
	if (iNum1 > iNum2)
	{
		tmp = iNum1;
		iNum1 = iNum2;
		iNum2 = tmp;
	}
	for (int i = iNum1; i <= iNum2; i++)
		m_iSum += i;
}

Quiz::~Quiz()
{
}
