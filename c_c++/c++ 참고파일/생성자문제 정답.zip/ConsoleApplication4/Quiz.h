#pragma once
class Quiz
{
private:
	int m_iSum;
public:
	Quiz();
	Quiz(int iNum);
	Quiz(int iNum1,int iNum2);
	inline int GetSum()
	{
		return m_iSum;
	}
	~Quiz();
};

