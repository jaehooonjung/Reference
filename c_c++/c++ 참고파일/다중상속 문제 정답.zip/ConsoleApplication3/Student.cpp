#include "Student.h"



Student::Student()
{
}

void Student::SetStudent()
{
	SetClass();
	SetPerson();
}
void Student::ShowStudent()
{
	ShowClass();
	ShowPerson();
}

Student::~Student()
{
}
