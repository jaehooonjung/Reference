#include"Student.h"
void main()
{
	Student st;
	st.SetStudent();
	system("cls");
	st.ShowStudent();
	system("pause");
}