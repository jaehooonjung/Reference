#pragma once
#include"Mecro.h"
#include"MapDraw.h"
class Map
{
private:
	int m_ix;
	int m_iy;
	int m_iWidth;
	int m_iHeight;
	MapDraw m_DrawManager;
public:
	void MapDraw();
	Map();
	~Map();
};

