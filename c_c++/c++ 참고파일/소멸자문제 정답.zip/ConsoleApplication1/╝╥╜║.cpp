#include"Number.h"
#include<conio.h>
void main()
{
	Number n;
	n.NumberDraw();
	getch();
}